<div class="error-area">
	<div class="d-table">
		<div class="d-table-cell">
			<div class="container">
				<div class="error-content card-box-style">
					<div class="account-header">
						<a href="inicio">
							<img src="assets/img/logo.png" alt="main-logo">
						</a>
						<h3>Registro de nuevos usuarios</h3>
					</div>
					<h1>404</h1>
					<h3>¡Ups! Página no encontrada</h3>
					<p>La página que buscabas no se pudo encontrar.</p>
					<a class="btn btn btn-primary" href="inicio">Volver a la página de inicio</a>
				</div>
			</div>
		</div>
	</div>
</div>