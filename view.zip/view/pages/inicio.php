<!-- Start Main Content Area -->
<main class="main-content-wrap">
	<?php 
		include "moduls/home/features.php";
		include "moduls/home/overview.php";
		include "moduls/home/tables.php";
	?>


</main>
<!-- End Main Content Area -->
</div>
<!-- End All Section Area -->

<!-- Start Go Top Area -->
<div class="go-top">
	<i class="ri-arrow-up-s-fill"></i>
	<i class="ri-arrow-up-s-fill"></i>
</div>
<!-- End Go Top Area -->
